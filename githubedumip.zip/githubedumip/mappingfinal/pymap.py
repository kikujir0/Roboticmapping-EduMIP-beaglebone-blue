path = r'C:\Users\\Desktop\backupbeaglebone\mappingfinal\text.txt'     #path of text file
readfile = open(path,'r')       #open text file in reading mode
d1=float(readfile.read(8))      #reads first 8 characters, save in variable d1 and convert as float, then 8 next etc
d2=float(readfile.read(8))
d3=float(readfile.read(8))
d4=float(readfile.read(8))
d5=float(readfile.read(8))
d6=float(readfile.read(8))
d7=float(readfile.read(8))
readfile.close()                #close file
d1=int(d1*3.4)                  #multiply by wheel radius to convert radians to cm
d2=int(d2*3.4)                  
d3=int(d3*3.4)
d4=int(d4*3.4)
d5=int(d5*3.4)
d6=int(d6*3.4)
d7=int(d7*3.4)
x=d3-d2+35                      #define x as length or width, +35 for calibration purposes
y=d4-d3+30                      #define y as length or width, +30 for calibration purposes
if x<y:                         #determine which is which
    long=y
    larg=x
else:
    long=x
    larg=y
print("longueur=%d+-10cm,largeur=%d+-10cm"%(long,larg)) #print out length and width
from turtle import *    #import turtle library
color('red', 'yellow')  #define colors used
begin_fill()            #start drawing
right(90)               #left rotation
forward(d1*10)          #move forward, with scaling factor
left(90)
forward(d2*10-d1*10)
left(90)
forward(d3*10-d2*10)
left(90)
forward(d4*10-d3*10)
left(90)
forward(d5*10-d4*10)
left(90)
forward(d6*10-d5*10)
left(90)
forward(d7*10-d6*10)
end_fill()          #finished drawing
done()              


